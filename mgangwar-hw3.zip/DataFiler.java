//Mridul Singh Gangwar
//mgangwar


package hw3;

public abstract class DataFiler {
	
	public abstract void writeFile(String filename);
	
	public abstract boolean readFile(String filename);

}
